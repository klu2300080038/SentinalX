from sklearn.ensemble import IsolationForest
import pandas as pd

def ml_anomaly_detection(df):
    """
    Runs Isolation Forest on per-user aggregated features
    """

    # Create required columns safely
    for col in ['is_failed']:
        if col not in df.columns:
            df[col] = 0

    if 'timestamp' in df.columns:
        df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')
        df['hour'] = df['timestamp'].dt.hour
        df['is_off_hours'] = df['hour'].apply(lambda x: 1 if x < 6 or x > 20 else 0)
    else:
        df['is_off_hours'] = 0

    if 'action' in df.columns:
        df['is_privilege_escalation'] = df['action'].astype(str).str.contains(
            'privilege', case=False
        ).astype(int)
    else:
        df['is_privilege_escalation'] = 0

    # Aggregate per user
    if 'user' not in df.columns:
        return pd.DataFrame()

    user_activity = df.groupby('user').agg({
        'is_failed': 'sum',
        'is_off_hours': 'sum',
        'is_privilege_escalation': 'sum'
    }).reset_index()

    model = IsolationForest(contamination=0.2, random_state=42)

    features = user_activity[['is_failed', 'is_off_hours', 'is_privilege_escalation']]
    model.fit(features)

    user_activity['anomaly'] = model.predict(features)
    user_activity['anomaly'] = user_activity['anomaly'].map({1: 0, -1: 1})

    return user_activity


def detect_bruteforce(df):
    if 'timestamp' not in df.columns or 'user' not in df.columns or 'is_failed' not in df.columns:
        return []

    df = df.sort_values('timestamp')
    suspicious_users = []

    for user in df['user'].unique():
        user_logs = df[(df['user'] == user) & (df['is_failed'] == 1)]

        for i in range(len(user_logs)):
            window = user_logs.iloc[i:i+5]
            if len(window) >= 5:
                time_diff = (window['timestamp'].iloc[-1] - window['timestamp'].iloc[0]).seconds
                if time_diff <= 300:
                    suspicious_users.append(user)

    return list(set(suspicious_users))


def detect_behavior_deviation(df, baseline):
    if baseline.empty:
        return pd.DataFrame()

    merged = df.merge(baseline, on='user', how='left')

    merged['hour_deviation'] = abs(merged.get('hour', 0) - merged.get('avg_login_hour', 0))
    merged['failed_deviation'] = abs(
        merged.get('is_failed', 0) - merged.get('avg_failed_rate', 0)
    )

    suspicious = merged[
        (merged['hour_deviation'] > 5) |
        (merged['failed_deviation'] > 0.5)
    ]

    return suspicious