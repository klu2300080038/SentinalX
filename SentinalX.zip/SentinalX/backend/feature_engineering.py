import pandas as pd
import random
from sklearn.ensemble import IsolationForest
from datetime import datetime


# ------------------------------------------------
# Utility Functions
# ------------------------------------------------

def normalize_columns(df):
    df.columns = df.columns.str.lower().str.strip()
    return df


def detect_column(df, possible_names):
    for name in possible_names:
        if name in df.columns:
            return name
    return None


# ------------------------------------------------
# Feature Engineering
# ------------------------------------------------

def generate_features(df):

    df = normalize_columns(df)

    status_col = detect_column(df, ['status', 'result', 'outcome', 'state'])
    user_col = detect_column(df, ['user', 'username', 'account'])
    ip_col = detect_column(df, ['ip', 'ip_address', 'source_ip'])
    action_col = detect_column(df, ['action', 'event', 'activity'])
    time_col = detect_column(df, ['timestamp', 'time', 'date'])

    # ------------------------------------------------
    # Timestamp Handling
    # ------------------------------------------------
    if time_col:
        df[time_col] = pd.to_datetime(df[time_col], errors='coerce')
        df['hour'] = df[time_col].dt.hour
    else:
        df['hour'] = 12  # default safe hour

    # ------------------------------------------------
    # Failed Login Detection
    # ------------------------------------------------
    if status_col:
        df['is_failed'] = df[status_col].astype(str).str.lower().str.contains(
            'fail|denied|error'
        ).astype(int)
    else:
        df['is_failed'] = 0

    # ------------------------------------------------
    # Off-Hours Detection (before 6AM or after 8PM)
    # ------------------------------------------------
    df['is_off_hours'] = df['hour'].apply(
        lambda x: 1 if x < 6 or x > 20 else 0
    )

    # ------------------------------------------------
    # Privilege Escalation Detection
    # ------------------------------------------------
    if action_col:
        df['is_privilege_escalation'] = df[action_col].astype(str).str.lower().str.contains(
            'admin|root|privilege|sudo'
        ).astype(int)
    else:
        df['is_privilege_escalation'] = 0

    # ------------------------------------------------
    # Isolation Forest Anomaly Detection
    # ------------------------------------------------
    if user_col:
        user_counts = df[user_col].value_counts()
        df['user_activity_count'] = df[user_col].map(user_counts)

        iso = IsolationForest(contamination=0.05, random_state=42)
        df['anomaly'] = iso.fit_predict(df[['user_activity_count']])
        df['anomaly'] = df['anomaly'].apply(lambda x: 1 if x == -1 else 0)
    else:
        df['anomaly'] = 0
        df['user_activity_count'] = 0

    # ------------------------------------------------
    # Brute Force Detection
    # ------------------------------------------------
    brute_force_flags = []

    if user_col and ip_col:
        grouped = df.groupby([user_col, ip_col])['is_failed'].sum().reset_index()
        suspicious = grouped[grouped['is_failed'] >= 5]

        for _, row in suspicious.iterrows():
            brute_force_flags.append(row[user_col])

    # ------------------------------------------------
    # User Activity Aggregation
    # ------------------------------------------------
    if user_col:
        user_activity = df.groupby(user_col).agg({
            'is_failed': 'sum',
            'is_off_hours': 'sum',
            'is_privilege_escalation': 'sum',
            'anomaly': 'sum'
        }).reset_index()

        user_activity = user_activity.rename(columns={user_col: 'user'})

    else:
        user_activity = pd.DataFrame()

    return user_activity, brute_force_flags


# ------------------------------------------------
# Geo IP Simulation
# ------------------------------------------------

def add_geo_location(df):

    df['country'] = [random.choice(
        ['USA', 'Germany', 'India', 'China', 'Brazil', 'Russia']
    ) for _ in range(len(df))]

    return df


# ------------------------------------------------
# Baseline Model
# ------------------------------------------------

def baseline_model(df):

    df = normalize_columns(df)

    user_col = detect_column(df, ['user', 'username', 'account'])

    if not user_col:
        return pd.DataFrame()

    baseline = df[user_col].value_counts().reset_index()
    baseline.columns = ['user', 'normal_activity_volume']

    return baseline