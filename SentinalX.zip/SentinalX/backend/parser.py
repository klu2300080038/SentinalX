import pandas as pd


def parse_log(uploaded_file):

    df = pd.read_csv(uploaded_file)

    # Normalize column names
    df.columns = df.columns.str.lower().str.strip()

    column_map = {}

    # Timestamp mapping
    for col in df.columns:
        if "time" in col or "date" in col:
            column_map[col] = "timestamp"

    # User mapping
    for col in df.columns:
        if "user" in col or "account" in col:
            column_map[col] = "user"

    # IP mapping
    for col in df.columns:
        if "ip" in col or "source" in col:
            column_map[col] = "ip"

    # Event mapping
    for col in df.columns:
        if "event" in col or "action" in col:
            column_map[col] = "event"

    # Level mapping
    for col in df.columns:
        if "level" in col or "severity" in col:
            column_map[col] = "level"

    df = df.rename(columns=column_map)

    # Ensure required fields exist
    required_fields = ["timestamp", "user", "ip", "event", "level"]

    for field in required_fields:
        if field not in df.columns:
            df[field] = "Unknown"

    return df