import smtplib
import ssl
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import os
from datetime import datetime
import pandas as pd

SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
SENDER_EMAIL = "helloworldhi112@gmail.com"
APP_PASSWORD = os.getenv("SOC_EMAIL_PASSWORD")  # Must be set in system env

def _send_email(user, risk_score, country, ip=None, device=None, technique="T1110 - Brute Force"):
    """Send a single alert email."""

    if APP_PASSWORD is None:
        print("SOC_EMAIL_PASSWORD not set. Email not sent.")
        return

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    html_content = f"""
    <html>
    <body style="font-family: Arial; background-color:#0f2027; color:white;">
        <h2 style="color:#ff4d4d;">🚨 CRITICAL SECURITY ALERT</h2>
        <p><b>User:</b> {user}</p>
        <p><b>Risk Score:</b> {risk_score}</p>
        <p><b>Country:</b> {country}</p>
        <p><b>IP Address:</b> {ip if ip else 'N/A'}</p>
        <p><b>Device:</b> {device if device else 'N/A'}</p>
        <p><b>MITRE ATT&CK Technique:</b> {technique}</p>
        <p><b>Timestamp:</b> {timestamp}</p>
        <hr>
        <p style="color:#00ffcc;">SentinelX SOC Engine</p>
    </body>
    </html>
    """

    message = MIMEMultipart()
    message["From"] = SENDER_EMAIL
    message["To"] = SENDER_EMAIL
    message["Subject"] = f"[CRITICAL ALERT] SentinelX Threat Detected - {user}"
    message.attach(MIMEText(html_content, "html"))

    context = ssl.create_default_context()

    try:
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls(context=context)
        server.login(SENDER_EMAIL, APP_PASSWORD)
        server.sendmail(SENDER_EMAIL, SENDER_EMAIL, message.as_string())
        server.quit()
        print(f"Alert email sent for {user}")
    except Exception as e:
        print("Email sending failed:", e)


def send_critical_alert(data, technique="T1110 - Brute Force"):
    """
    Accepts either:
    - single user (string)
    - OR dataframe of flagged users with columns: 'user', 'risk_score', 'country', 'ip_address', 'device'
    """
    if isinstance(data, pd.DataFrame):
        for _, row in data.iterrows():
            _send_email(
                user=row["user"],
                risk_score=row.get("risk_score", "N/A"),
                country=row.get("country", "Unknown"),
                ip=row.get("ip_address"),
                device=row.get("device"),
                technique=technique
            )
    else:
        # single user fallback
        _send_email(
            user=data,
            risk_score="N/A",
            country="Unknown",
            ip=None,
            device=None,
            technique=technique
        )