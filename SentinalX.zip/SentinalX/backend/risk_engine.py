import pandas as pd


def calculate_risk(user_activity, bruteforce_users):

    if user_activity.empty:
        return user_activity

    user_activity['risk_score'] = 0

    # Base scoring
    user_activity['risk_score'] += user_activity['is_failed'] * 2
    user_activity['risk_score'] += user_activity['is_off_hours'] * 1.5
    user_activity['risk_score'] += user_activity['is_privilege_escalation'] * 6
    user_activity['risk_score'] += user_activity['anomaly'] * 4

    # Brute force penalty
    user_activity.loc[
        user_activity['user'].isin(bruteforce_users),
        'risk_score'
    ] += 15

    # ------------------------------------------------
    # MITRE ATT&CK Mapping
    # ------------------------------------------------
    def map_mitre(row):

        if row['is_privilege_escalation'] > 0:
            return "T1068 - Privilege Escalation"
        elif row['is_failed'] > 5:
            return "T1110 - Brute Force"
        elif row['anomaly'] > 0:
            return "T1078 - Valid Accounts Abuse"
        else:
            return "Normal Activity"

    user_activity['mitre_technique'] = user_activity.apply(map_mitre, axis=1)

    # ------------------------------------------------
    # Risk Levels
    # ------------------------------------------------
    def risk_label(score):
        if score >= 20:
            return "Critical"
        elif score >= 12:
            return "High"
        elif score >= 6:
            return "Medium"
        else:
            return "Low"

    user_activity['risk_level'] = user_activity['risk_score'].apply(risk_label)

    return user_activity