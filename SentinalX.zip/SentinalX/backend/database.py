from sqlalchemy import create_engine, text
import pandas as pd

DB_PATH = "sentinelx.db"
engine = create_engine(f"sqlite:///{DB_PATH}", echo=False)


# ---------------------------------------
# Initialize Database (Schema Control)
# ---------------------------------------
def initialize_database():
    with engine.connect() as conn:
        # Logs table
        conn.execute(text("""
        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user TEXT,
            is_failed INTEGER,
            is_off_hours INTEGER,
            is_privilege_escalation INTEGER,
            anomaly INTEGER,
            country TEXT
        )
        """))

        # Risk table
        conn.execute(text("""
        CREATE TABLE IF NOT EXISTS risk_scores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user TEXT,
            risk_score REAL,
            risk_level TEXT
        )
        """))

        conn.commit()


# ---------------------------------------
# Save Logs
# ---------------------------------------
def save_logs(df):
    df = df[[
        'user',
        'is_failed',
        'is_off_hours',
        'is_privilege_escalation',
        'anomaly',
        'country'
    ]]

    df.to_sql("audit_logs", engine, if_exists="append", index=False)


# ---------------------------------------
# Save Risk
# ---------------------------------------
def save_risk(risk_df):
    risk_df = risk_df[['user', 'risk_score', 'risk_level']]
    risk_df.to_sql("risk_scores", engine, if_exists="append", index=False)


# ---------------------------------------
# Load Data
# ---------------------------------------
def load_logs():
    return pd.read_sql("SELECT * FROM audit_logs", engine)


def load_risk():
    return pd.read_sql("SELECT * FROM risk_scores", engine)