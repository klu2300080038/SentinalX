import hashlib

# Simple SHA256 hashing for hackathon stability
def hash_password(password: str):
    return hashlib.sha256(password.encode()).hexdigest()

# Demo users
users = {
    "admin": hash_password("admin123"),
    "soc_analyst": hash_password("soc123")
}

def authenticate(username, password):
    if username in users:
        return users[username] == hash_password(password)
    return False