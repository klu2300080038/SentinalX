from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch

def generate_pdf(user_activity):
    doc = SimpleDocTemplate("SentinelX_Report.pdf")
    elements = []
    styles = getSampleStyleSheet()

    elements.append(Paragraph("SentinelX Threat Analysis Report", styles['Heading1']))
    elements.append(Spacer(1, 0.5 * inch))

    data = [user_activity.columns.tolist()] + user_activity.values.tolist()
    table = Table(data)

    elements.append(table)
    doc.build(elements)