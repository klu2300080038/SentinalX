def fetch_windows_security_logs():
    try:
        import win32evtlog

        server = 'localhost'
        log_type = 'Security'

        hand = win32evtlog.OpenEventLog(server, log_type)
        events = win32evtlog.ReadEventLog(
            hand,
            win32evtlog.EVENTLOG_BACKWARDS_READ | win32evtlog.EVENTLOG_SEQUENTIAL_READ,
            0
        )

        logs = []
        for event in events[:10]:
            logs.append({
                "EventID": event.EventID,
                "SourceName": event.SourceName
            })

        return logs

    except Exception as e:
        return [{"error": "Admin privilege required to access Windows Security Logs."}]