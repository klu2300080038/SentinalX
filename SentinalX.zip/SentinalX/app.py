import streamlit as st
import pandas as pd
import plotly.express as px
import time
from datetime import datetime, timedelta
import random

from backend.parser import parse_log
from backend.feature_engineering import generate_features, baseline_model, add_geo_location
from backend.detection_engine import (
    ml_anomaly_detection,
    detect_bruteforce,
    detect_behavior_deviation
)
from backend.risk_engine import calculate_risk
from backend.report_generator import generate_pdf
from backend.database import save_logs, save_risk, initialize_database
from backend.auth import authenticate
from backend.windows_log_stream import fetch_windows_security_logs
from backend.alert_engine import send_critical_alert

# ==================================================
# INITIALIZE DATABASE
# ==================================================
initialize_database()

# ==================================================
# PAGE CONFIG
# ==================================================
st.set_page_config(page_title="SentinelX SOC", layout="wide")
st.markdown("""
<style>
.stApp {
    background: linear-gradient(to right, #0f2027, #203a43, #000000);
    color: #00ffcc;
}
h1, h2, h3 { color: #00ffcc; }
section[data-testid="stSidebar"] { background-color: #0a0f14; }
</style>
""", unsafe_allow_html=True)

# ==================================================
# BRUTE FORCE SIMULATION FUNCTION
# ==================================================
def simulate_bruteforce_attack(df):
    """Inject realistic brute force logs for first user"""
    if "user" not in df.columns:
        return df

    target_user = df["user"].iloc[0]
    now = datetime.now()
    countries = ["China", "Russia", "US", "Germany", "Brazil"]
    attack_rows = []

    for i in range(20):
        attack_rows.append({
            "timestamp": now + timedelta(seconds=i),
            "user": target_user,
            "ip_address": f"192.168.{random.randint(1,255)}.{random.randint(1,255)}",
            "device": f"Windows-PC-{random.randint(1,5)}",
            "country": random.choice(countries),
            "location": random.choice(countries),
            "is_failed": 1,
            "is_off_hours": random.choice([0,1]),
            "is_privilege_escalation": 0,
            "anomaly": 1
        })

    attack_df = pd.DataFrame(attack_rows)
    for col in df.columns:
        if col not in attack_df.columns:
            attack_df[col] = None

    df = pd.concat([df, attack_df], ignore_index=True)
    return df

# ==================================================
# AUTHENTICATION
# ==================================================
if "authenticated" not in st.session_state:
    st.session_state.authenticated = False

if not st.session_state.authenticated:
    st.title("🔐 SentinelX SOC Login")
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")

    if st.button("Login"):
        if authenticate(username, password):
            st.session_state.authenticated = True
            st.success("Access Granted")
            st.rerun()
        else:
            st.error("Access Denied")
    st.stop()

# ==================================================
# DASHBOARD
# ==================================================
st.title("🛡 SentinelX SOC Dashboard")
st.caption("Enterprise Threat Detection | MITRE ATT&CK | ML Powered")
uploaded_file = st.file_uploader("Upload Audit Log CSV", type=["csv"])

if uploaded_file:
    df = parse_log(uploaded_file)
    df.columns = df.columns.str.lower().str.strip()
    if "timestamp" in df.columns:
        df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    if "country" not in df.columns:
        df["country"] = "Unknown"

    df = add_geo_location(df)

    # Feature engineering
    user_activity, _ = generate_features(df)
    if user_activity.empty:
        st.warning("No user activity detected.")
        st.stop()

    ml_results = ml_anomaly_detection(df)
    if not ml_results.empty:
        ml_results = ml_results.drop_duplicates(subset=["user"])
        user_activity = user_activity.merge(
            ml_results[["user", "anomaly"]],
            on="user",
            how="left"
        )

    for col in ["is_failed", "is_off_hours", "is_privilege_escalation", "anomaly"]:
        if col not in user_activity.columns:
            user_activity[col] = 0
    user_activity = user_activity.drop_duplicates(subset=["user"]).fillna(0)

    # Detect brute force & risk
    bruteforce_users = detect_bruteforce(df)
    user_activity = calculate_risk(user_activity, bruteforce_users)

    # Behavioral deviations
    baseline = baseline_model(df)
    deviation_logs = detect_behavior_deviation(df, baseline) if baseline is not None else pd.DataFrame()

    # Save to DB
    try:
        save_logs(df)
        save_risk(user_activity)
    except Exception as e:
        st.warning(f"Database Warning: {e}")

    # =======================
    # METRICS
    # =======================
    st.subheader("🚨 Threat Intelligence Overview")
    col1, col2, col3 = st.columns(3)
    col1.metric("Total Users", len(user_activity))
    col2.metric("High Risk", len(user_activity[user_activity["risk_level"] == "High"]))
    col3.metric("Critical", len(user_activity[user_activity["risk_level"] == "Critical"]))

    # Send alerts
    critical_users = user_activity[user_activity["risk_level"] == "Critical"]
    if not critical_users.empty:
        send_critical_alert(critical_users)

    # =======================
    # USER TABLE
    # =======================
    st.subheader("📊 User Risk Table")
    st.dataframe(user_activity.sort_values("risk_score", ascending=False))

    # =======================
    # BAR CHART
    # =======================
    st.subheader("📈 Risk Score by User")
    st.plotly_chart(px.bar(user_activity, x="user", y="risk_score", color="risk_level"), use_container_width=True)

    # =======================
    # TIMELINE
    # =======================
    st.subheader("⏳ Security Event Timeline")
    if "timestamp" in df.columns:
        timeline = df.dropna(subset=["timestamp"]).groupby(df["timestamp"].dt.floor("1H")).size().reset_index(name="events")
        st.plotly_chart(px.line(timeline, x="timestamp", y="events", markers=True), use_container_width=True)

    # =======================
    # GEO MAP
    # =======================
    st.subheader("🌍 Threat Distribution Map")
    geo_data = df.groupby("country").size().reset_index(name="events")
    st.plotly_chart(px.choropleth(geo_data, locations="country", locationmode="country names",
                                  color="events", color_continuous_scale="Reds"), use_container_width=True)

    # =======================
    # BEHAVIORAL DEVIATION
    # =======================
    st.subheader("⚠ Behavioral Deviations")
    if not deviation_logs.empty:
        st.dataframe(deviation_logs)
    else:
        st.success("No behavioral deviation detected.")

    # =======================
    # SIDEBAR CONTROLS
    # =======================
    st.sidebar.title("⚙ SOC Controls")

    if st.sidebar.button("📡 Fetch Windows Logs"):
        st.write(fetch_windows_security_logs())

    if st.sidebar.button("🚨 Detect Brute Force Attack"):
        manual_bruteforce = detect_bruteforce(df)
        if manual_bruteforce:
            user_activity.loc[user_activity["user"].isin(manual_bruteforce), "risk_score"] += 30
            user_activity = calculate_risk(user_activity, manual_bruteforce)
            flagged = user_activity[user_activity["user"].isin(manual_bruteforce)]
            st.dataframe(flagged)
            send_critical_alert(flagged)
        else:
            st.success("No brute force detected.")

    if st.sidebar.button("💣 Simulate Brute Force Attack"):
        df = simulate_bruteforce_attack(df)
        st.warning("Simulated brute force attack injected.")
        simulated_users = detect_bruteforce(df)
        if simulated_users:
            user_activity.loc[user_activity["user"].isin(simulated_users), "risk_score"] += 40
            user_activity = calculate_risk(user_activity, simulated_users)
            flagged = user_activity[user_activity["user"].isin(simulated_users)]
            st.error("🚨 Simulated Brute Force Detected")
            st.dataframe(flagged)
            send_critical_alert(flagged)

    if st.sidebar.button("Start Real-Time Monitoring"):
        with st.spinner("Monitoring..."):
            time.sleep(3)
        st.success("Monitoring Complete")

    if st.button("📄 Generate Threat Report"):
        generate_pdf(user_activity)
        st.success("PDF Report Generated")

    # =======================
    # RAW LOG DATA
    # =======================
    st.subheader("📜 Raw Log Data")
    st.dataframe(df)